from PIL import Image, ImageDraw
import colorsys



for i in range(1,8):
    im = Image.open("stationgalaxie_1.png")
    image = im.load()
    largeur, hauteur = im.size
    for x in range(largeur):
        for y in range(hauteur):
            r, v, b, o= image[x, y]
            min1 = min( r, v, b)
            max1 = max( r, v, b)
            if(2.0-max1-min1) != 0:
                h, l, s = colorsys.rgb_to_hls(r, v, b)
            if 0.70 < h < 0.96:
                h+= i*1/8
                r, v, b = colorsys.hls_to_rgb(h, l, s)
                image[x, y] = (int(r), int(v), int(b), o)
    im.save("stationgalaxie_{0}.png".format(i+1))
