from PIL import Image, ImageDraw




for i in range(0,8):
    im = Image.open("attaque_1.png")
    im.rotate(i*45)
    im.save("{0}attaque_{0}.png".format(i*45))
