from PIL import Image, ImageDraw

fichier = ("attaque_","cargo_","sonde_")

for f in fichier:
    for k in range(1,9):
        for i in range(0,8):
            im = Image.open(f+"{0}.png".format(k)) 
            angle = i*45
            if(angle==180):
                image = im.transpose(Image.FLIP_LEFT_RIGHT)
                image.save("{0}".format(angle)+f+"{0}.png".format(k))
            elif(angle==135):
                im = Image.open("45"+f+"{0}.png".format(k))
                image= im.transpose(Image.FLIP_LEFT_RIGHT)
                image.save("{0}".format(angle)+f+"{0}.png".format(k))
            elif(angle==225):
                im = Image.open("180"+f+"{0}.png".format(k))
                image = im.rotate(45, expand=True)
                image.save("{0}".format(angle)+f+"{0}.png".format(k))
            elif(angle==270):
                im = Image.open("180"+f+"{0}.png".format(k))
                image = im.rotate(90,expand=True)
                image.save("{0}".format(angle)+f+"{0}.png".format(k))
            else:
                image=im.rotate(angle, expand=True)
                image.save("{0}".format(angle)+f+"{0}.png".format(k))

